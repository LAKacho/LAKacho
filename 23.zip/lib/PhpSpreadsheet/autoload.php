<?php
spl_autoload_register(function ($class) {
    // Проверяем, принадлежит ли класс пространству имён PhpOffice\PhpSpreadsheet
    $prefix = 'PhpOffice\\PhpSpreadsheet\\';
    $base_dir = __DIR__ . '/src/';

    // Проверка префикса
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        // Если класс не начинается с нужного префикса, пропускаем
        return;
    }

    // Получаем относительное имя класса
    $relative_class = substr($class, $len);

    // Формируем полный путь к файлу класса
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    // Проверяем существование файла и подключаем его
    if (file_exists($file)) {
        require $file;
    }
});
?>
