<?php
// Подключение к основной базе данных
$host = 'localhost';
$dbname_main = '1test_system';
$dbname_secondary = '360_la';
$user = 'root';
$pass = '';

try {
    // Подключение к основной базе данных
    $pdo = new PDO("mysql:host=$host;dbname=$dbname_main;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Подключение ко второй базе данных
    $pdo_secondary = new PDO("mysql:host=$host;dbname=$dbname_secondary;charset=utf8", $user, $pass);
    $pdo_secondary->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}
?>