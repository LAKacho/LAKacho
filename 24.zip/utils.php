<?php
function check_restrictions($pdo, $tab_number, $test_name) {
    // Условия ограничения для каждого теста
    $restrictions = [
        'Старшинство' => 120, // 120 дней
        'Наставничество' => 300, // 300 дней
        'Базовые управленческие навыки' => 300, // 300 дней
        'default' => 1 // Ограничение записи раз в день для остальных тестов
    ];

    // Получаем ограничение для выбранного теста
    $required_interval = $restrictions[$test_name] ?? $restrictions['default'];

    // Проверяем последнюю запись из базы данных
    $stmt = $pdo->prepare("SELECT MAX(date_time) AS last_date FROM test_registrations WHERE tab_number = ? AND test_name = ?");
    $stmt->execute([$tab_number, $test_name]);
    $result = $stmt->fetch();

    if ($result['last_date']) {
        $last_date = new DateTime($result['last_date']);
        $current_date = new DateTime();

        // Рассчитываем разницу в днях
        $interval = $current_date->diff($last_date)->days;

        // Проверяем, соблюдается ли интервал для записи
        if ($interval < $required_interval) {
            // Если ограничения нарушены, возвращаем username (табельный номер)
            $stmt = $pdo->prepare("SELECT username FROM users WHERE username = ?");
            $stmt->execute([$tab_number]);
            $user = $stmt->fetch();
            return $user['username'] ?? null;
        }
    }

    // Если пользователь может записаться, возвращаем true
    return true;
}
?>
