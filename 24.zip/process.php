<?php
session_start();
include 'db.php';
include 'utils.php';
require 'vendor/autoload.php';

// Конфигурация сроков действия тестов
define("TEST_DURATIONS", [
    "Старшинство" => 180,
    "Наставничество" => 360,
    "Базовые навыки" => 360
]);

// Шаг 1: Пользователь выбрал тест
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test']) && !isset($_POST['tab_number'])) {
    $_SESSION['test'] = $_POST['test'];
    displayTabNumberForm();
    exit;
}

// Шаг 2: Пользователь ввел логин
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tab_number'])) {
    $login = $_POST['tab_number']; // Используем `tab_number` как логин
    $test_name = $_SESSION['test'] ?? null;

    if (!$test_name) {
        displayError("Ошибка: тест не выбран.");
        exit;
    }

    try {
        // Проверка логина во второй базе данных
        $user_info = getUserInfoFromSecondaryDB($pdo_secondary, $login);
        if (!$user_info) {
            displayError("Ваш логин \"$login\" не найден в системе. Обратитесь к администратору.");
            exit;
        }

        $name = $user_info['password']; // Используем `password` как имя пользователя

        // Проверка условий записи
        $message = checkTestEligibility($pdo, $login, $test_name, $name); // Передаём $name в функцию
        if ($message !== true) {
            displayError($message);
            exit;
        }

        // Запись в основную базу данных
        $current_date = date('Y-m-d H:i:s');
        registerTest($pdo, $login, $test_name, $current_date);

        // Успешное сообщение
        displaySuccessMessage($test_name, $name);
    } catch (Exception $e) {
        displayError("Произошла ошибка: " . $e->getMessage());
    }
}

// Форма ввода логина
function displayTabNumberForm() {
    echo "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Ввод логина</title>
            <link rel='stylesheet' href='styles.css'>
        </head>
        <body>
            <div class='container'>
                <header>
                    <h1 class='title'>Введите ваш логин</h1>
                </header>
                <div class='content'>
                    <form action='process.php' method='POST' class='form'>
                        <label for='tab_number' class='label'>Логин:</label>
                        <input type='text' id='tab_number' name='tab_number' placeholder='Введите логин' required class='input'>
                        <button type='submit' class='button'>Записаться</button>
                    </form>
                </div>
            </div>
        </body>
        </html>
    ";
}

// Проверка пользователя во второй базе данных
function getUserInfoFromSecondaryDB($pdo_secondary, $login) {
    try {
        $stmt = $pdo_secondary->prepare("SELECT username, password FROM users WHERE username = ?");
        $stmt->execute([$login]);
        return $stmt->fetch();
    } catch (Exception $e) {
        logError("Ошибка проверки логина в базе данных: " . $e->getMessage());
        return false;
    }
}

// Проверка условий записи
function checkTestEligibility($pdo, $login, $test_name, $name) {
    $today = date('Y-m-d');
    $required_interval = TEST_DURATIONS[$test_name] ?? 1;

    try {
        $stmt = $pdo->prepare("SELECT MAX(date_time) AS last_date FROM test_registrations WHERE tab_number = ? AND test_name = ?");
        $stmt->execute([$login, $test_name]);
        $last_record = $stmt->fetch();

        if ($last_record && $last_record['last_date']) {
            $last_date = new DateTime($last_record['last_date']);
            $current_date = new DateTime();

            // Проверяем интервал с последней записью
            $interval = $current_date->diff($last_date)->days;

            if ($interval < $required_interval) {
                $next_available_date = $last_date->modify("+$required_interval days")->format('Y-m-d');
                return "<b>$name</b>, вы не можете записаться на тест \"$test_name\". Следующая доступная дата: $next_available_date.";
            }
        }
    } catch (Exception $e) {
        logError("Ошибка проверки условий записи: " . $e->getMessage());
        return "Произошла ошибка при проверке условий.";
    }

    return true;
}

// Регистрация теста в основной базе данных
function registerTest($pdo, $login, $test_name, $current_date) {
    try {
        $stmt = $pdo->prepare("INSERT INTO test_registrations (tab_number, test_name, date_time) VALUES (?, ?, ?)");
        $stmt->execute([$login, $test_name, $current_date]);
    } catch (Exception $e) {
        logError("Ошибка записи теста: " . $e->getMessage());
        throw $e;
    }
}

// Успешное сообщение
function displaySuccessMessage($test_name, $name) {
    renderPage("Запись успешна", "
        <p class='success'>Добро пожаловать, <b>$name</b>! Вы успешно записались на тест <b>$test_name</b>.</p>
        <form action='index.php' method='GET'>
            <button type='submit' class='button'>Вернуться на главное меню</button>
        </form>
    ");
}

// Вывод ошибки
function displayError($message) {
    renderPage("Ошибка", "
        <p class='error'>$message</p>
        <form action='index.php' method='GET'>
            <button type='submit' class='button'>Вернуться на главное меню</button>
        </form>
    ");
}

// Логирование ошибок
function logError($error_message) {
    file_put_contents('errors.log', "[" . date('Y-m-d H:i:s') . "] " . $error_message . PHP_EOL, FILE_APPEND);
}

// Общая функция для рендеринга страниц
function renderPage($title, $content) {
    echo "
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>$title</title>
            <link rel='stylesheet' href='styles.css'>
        </head>
        <body>
            <div class='container'>
                <header>
                    <h1 class='title'>$title</h1>
                </header>
                <div class='content'>
                    $content
                </div>
            </div>
        </body>
        </html>
    ";
}
?>
